$(document).ready(function () {
    console.log("app");

    $(".modal").on("hidden.bs.modal", function () {
        window.location.reload();
    });

    var table = $('#userTable').DataTable({
        colReorder: true,
        dom: 'Zlfrtip',
        colResize: {
            "tableWidthFixed": false
        },
        iDisplayLength: 100,
        aoColumnDefs: [{
                bSortable: false,
                aTargets: 'nosort'
            }],
        language: {
            searchPlaceholder: "Search"
        },
        aaSorting: []
    });

    $("#form").submit(function () {
        $("#formButton").button("loading");
    });
});