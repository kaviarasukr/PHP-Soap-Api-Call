
<?php require_once("include/modal.php"); ?>
<!-- Bootstrap core JavaScript
        ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="custom/js/jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="toastr/toastr.min.js"></script>
<script src="dataTable/js/jquery.dataTables.min.js"></script>
<script src="dataTable/js/dataTables.bootstrap.min.js"></script>
<script src="dataTable/js/dataTables.colReorder.js"></script>
<script src="dataTable/js/dataTables.colResize.js"></script>
<script src="dataTable/js/dataTables.rowsGroup.js"></script>

<script src="custom/js/app.js"></script>
<script src="custom/js/users.js"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="custom/js/ie10-viewport-bug-workaround.js"></script>
<div class="footer">
    <p><strong>Contact information:</strong> <a href="mailto:sales@thebathandtiledepot.co.uk">sales@thebathandtiledepot.co.uk</a>.</p>
    <p><strong>Note:</strong> This application allows you to check the <strong>Ultra Finishing</strong> web stock details.</p>
    <p><strong>Hosted by:</strong>The Bath and Tile Depot.&copy;2017 All Rights Reserved.</p>
</div>


</body>
</html>
