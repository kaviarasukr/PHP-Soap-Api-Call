$(document).ready(function () {
    console.log("user");

    $(".userForm").submit(function (e) {
        e.preventDefault();
        $("#userFormButton").button("loading");
        var formData = $(this).serialize();

        $.ajax({
            type: "POST",
            url: "functions/userFunctions.php",
            dataType: "json",
            data: formData,
            success: function (data) {
                $("#userFormButton").button("reset");
                toastr[data.results](data.response, data.results.charAt(0).toUpperCase() + data.results.slice(1));
            }
        });
    });

    $(".dataTable").on("click", ".editUser", function () {
        var id = $(this).attr("data-id");

        $.ajax({
            type: "POST",
            url: "functions/userFunctions.php",
            dataType: "json",
            data: "id=" + id + "&action=getUser",
            success: function (data) {
                $("#modalTitle").text("Edit Staff");
                $("#action").val("editUser");

                $("#name").val(data.name);
                $("#username").val(data.username);
                $("#password").val("******");
                $("#conformPassword").val("******");
                $("#userId").val(data.id);
                $("#userFormButton").html("Edit");
                $("#userFormButton").attr("data-loading-text", "<i class='fa fa-circle-o-notch fa-spin fa-fw'></i> Edit")
                $("#userModal").modal("show");
            }
        });
    });

    $(".dataTable").on("change", ".editType", function () {
        var type = $(this).val();
        var id = $(this).attr("data-id");

        $.ajax({
            type: "POST",
            url: "functions/userFunctions.php",
            dataType: "json",
            data: "id=" + id + "&type=" + type + "&action=editType",
            success: function (data) {
                toastr[data.results](data.response, data.results.charAt(0).toUpperCase() + data.results.slice(1));
            }
        });
    });

    $("#updateProfileForm").submit(function (e) {
        e.preventDefault();
        var formData = $(this).serialize();
        $("#updateProfileFormButton").button("loading");

        $.ajax({
            type: "POST",
            url: "functions/userFunctions.php",
            dataType: "json",
            data: formData,
            success: function (data) {
                $("#updateProfileFormButton").button("reset");
                toastr[data.results](data.response, data.results.charAt(0).toUpperCase() + data.results.slice(1));
            }
        });
    });


    $(".dataTable").on("click", ".deleteUser", function () {
        var userId = $(this).attr("data-id");
        $("#deleteUserId").val(userId);
        $("#userDeleteModal").modal("show");
    });

    $("#deleteUserForm").submit(function (e) {
        e.preventDefault();
        $("#deleteUserFormButton").button("loading");
        $.ajax({
            type: "POST",
            url: "functions/userFunctions.php",
            dataType: "json",
            data: $(this).serialize(),
            success: function (data) {
                $("#deleteUserFormButton").button("reset");
                toastr[data.results](data.response, data.results.charAt(0).toUpperCase() + data.results.slice(1));
            }
        });
    });
});