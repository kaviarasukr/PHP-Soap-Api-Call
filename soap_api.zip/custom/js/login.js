$(document).ready(function ($) {
    console.log("login");

    $(".login-form").submit(function (e) {
        e.preventDefault();
        $("#loginFormButton").button("loading");
        var formData = $(this).serialize();

        $.ajax({
            type: "POST",
            url: "functions/loginFunctions.php",
            data: formData + "&action=login",
            dataType: "json",
            success: function (data) {
                $("#loginFormButton").button("reset");
                toastr[data.results](data.response);
                if (data.results == "success") {
                    window.location.href = "home.php";
                }
            }
        });
    });

    $.backstretch([
        "img/bg1.png",
        "img/bg2.png"
    ], {duration: 3000, fade: 750});
});

