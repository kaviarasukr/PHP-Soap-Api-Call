<?php

session_start();
set_time_limit(0);

require_once("../db/AppManager.php");
$pm = AppManager::getPM();

$input = $_REQUEST;
$action = $input['action'];
unset($input['action']);

if ($action == "login") {
    login($input);
}

function login($input) {
    global $pm;

    $username = $input['username'];
    $password = $input['password'];

    $userExist = $pm->getCount("SELECT COUNT(*)c FROM `users` WHERE `username`='$username' AND `password`=MD5('$password')");
    if (!$userExist) {
        echo json_encode(['results' => 'error', 'response' => 'Invalid Username or Password!']);
        exit;
    } else {
        $staffDetails = $pm->fetchResult("SELECT * FROM `users` WHERE `username`='$username' AND `password`=MD5('$password')");

        $_SESSION['user'] = $staffDetails[0];
        $_SESSION['logged_in'] = true;

        echo json_encode(['results' => 'success', 'response' => 'Successfully logged in!']);
        exit;
    }
}
