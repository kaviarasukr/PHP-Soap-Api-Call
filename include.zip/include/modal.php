
<!-- Profile Modal -->
<div class="modal fade" id="profileModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">My Profile Details</h4>
            </div>
            <form role="form" id="updateProfileForm">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="">Name:</label>
                        <input type="text" class="form-control input-sm" id="" name="name" value="<?= $_SESSION['user']['name']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="">Password:</label>
                        <input type="password" class="form-control input-sm" id="" name="password" value="******" placeholder="Password">
                    </div>
                    <div class="form-group">
                        <label for="">Conform Password:</label>
                        <input type="password" class="form-control input-sm" id="" name="conform_password" value="******" placeholder="Conform Password">
                        <input type="hidden" name="action" value="updateProfile"/>
                        <input type="hidden" name="user_id" value="<?= $_SESSION['user']['id']; ?>"/>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success btn-sm" id="updateProfileFormButton" data-loading-text="Updating...">Update</button>
                    <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>

