<?php

session_start();
require_once("../db/AppManager.php");
$pm = AppManager::getPM();

$input = $_REQUEST;
$action = $input['action'];
unset($input['action']);

if ($action == "createUser") {
    createUser($input);
} else if ($action == "editUser") {
    editUser($input);
} else if ($action == "getUser") {
    getUser($input);
} else if ($action == "editType") {
    editType($input);
} else if ($action == "updateProfile") {
    updateProfile($input);
} else if ($action == "deleteUser") {
    deleteUser($input);
}

function createUser($input) {
    global $pm;

    $name = addslashes(trim($input['name']));
    $username = addslashes(trim($input['username']));
    $password = addslashes(trim($input['password']));
    $conformPassword = addslashes(trim($input['conform_password']));

    if ($password != $conformPassword) {
        echo json_encode(['results' => 'error', 'response' => 'Password doesn\'t match']);
        exit;
    }

    $usernameExist = $pm->getCount("SELECT COUNT(*)c FROM `users` WHERE `username` LIKE '$username'");
    if ($usernameExist) {
        echo json_encode(['results' => 'error', 'response' => 'Username already exist!']);
        exit;
    }

    $pm->executeQuery("INSERT INTO `users` (`name`,`username`,`password`,`created_at`) VALUES ('$name','$username',MD5('$password'),NOW())");
    echo json_encode(['results' => 'success', 'response' => 'User created successfully!']);
    exit;
}

function editUser($input) {
    global $pm;

    $userId = trim($input['userId']);
    $name = addslashes(trim($input['name']));
    $username = addslashes(trim($input['username']));
    $password = addslashes(trim($input['password']));
    $conformPassword = addslashes(trim($input['conform_password']));

    if ($password != "******") {
        if ($password != $conformPassword) {
            echo json_encode(['results' => 'error', 'response' => 'Password doesn\'t match']);
            exit;
        }
    }

    $usernameExist = $pm->getCount("SELECT COUNT(*)c FROM `users` WHERE `username` LIKE '$username' AND `id`<> $userId");
    if ($usernameExist) {
        echo json_encode(['results' => 'error', 'response' => 'Username already exist!']);
        exit;
    }

    if ($password != "******" && !empty($password)) {
        $pm->executeQuery("UPDATE `users` SET `name`='$name',`username`='$username',`password`=MD5('$password') WHERE `id`='$userId'");
    } else {
        $pm->executeQuery("UPDATE `users` SET `name`='$name',`username`='$username' WHERE `id`='$userId'");
    }
    $_SESSION['user']['name'] = $name;
    echo json_encode(['results' => 'success', 'response' => 'User edited successfully!']);
    exit;
}

function getUser($input) {
    global $pm;

    $id = $input['id'];
    $response = $pm->fetchResult("SELECT * FROM `users` WHERE `id`='$id'");
    echo json_encode($response[0]);
    exit;
}

function editType($input) {
    global $pm;

    $id = $input['id'];
    $type = $input['type'];

    $pm->executeQuery("UPDATE `users` SET `type`='$type' WHERE `id`='$id'");
    $_SESSION['user']['type'] = $type;
    echo json_encode(['results' => 'success', 'response' => 'Type Changed!!']);
    exit;
}

function updateProfile($input) {
    global $pm;

    $password = $input['password'];
    $conformPassword = $input['conform_password'];
    if ($password != "******") {
        if ($password != $conformPassword) {
            echo json_encode(['results' => 'error', 'response' => 'Password doesn\'t match!!']);
            exit;
        }
    }

    $name = $input['name'];
    $userId = $input['user_id'];

    $_SESSION['user']['name'] = $name;
    if ($password != "******" && !empty($password)) {
        $pm->executeQuery("UPDATE `users` SET `name`='$name',`password`=MD5('$password') WHERE `id`='$userId'");
    } else {
        $pm->executeQuery("UPDATE `users` SET `name`='$name' WHERE `id`='$userId'");
    }
    echo json_encode(['results' => 'success', 'response' => 'Detail updated successfully!']);
    exit;
}

function deleteUser($input) {
    global $pm;

    $deleteUser = $input['deleteUserId'];
    $currentUserId = $input['currentUserId'];

    if ($deleteUser == $currentUserId) {
        echo json_encode(['results' => 'error', 'response' => 'Cannot delete logged in user']);
        exit;
    }

    $pm->executeQuery("DELETE FROM `users` WHERE `id`='$deleteUser'");
    echo json_encode(['results' => 'success', 'response' => 'User deleted!!']);
    exit;
}
